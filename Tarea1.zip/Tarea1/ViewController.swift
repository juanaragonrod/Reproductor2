//
//  ViewController.swift
//  Tarea1
//
//  Created by Juan Rrodrigez on 29/10/16.
//  Copyright © 2016 Juan Aragon Rodriguez. All rights reserved.
//

import UIKit
import AVFoundation


class ViewController: UIViewController {
    
    @IBOutlet weak var song: UILabel!
    @IBOutlet weak var artist: UILabel!
    @IBOutlet weak var volum: UISlider!
    @IBOutlet weak var imagen: UIImageView!
    
    private var pistas = ["Wrong","Depeche Mode","01","Vertigo","U2","02","Come Back","Pearl Jam","03","Do I Wanna Know?","Arctic Monkeys","04","Friday I'm in Love","The Cure","05"]
    
    //private var activado=false;
    private var reproductor: AVAudioPlayer!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let sonidoURL = Bundle.main.url(forResource: "pista" + pistas[2],withExtension:"aif")
        //self.soundFileURLRef = sonidoURL
        do{
            reproductor = try AVAudioPlayer(contentsOf: sonidoURL!)
        }catch{
            print("Error al cargar la cancion")
        }
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    private func repro(Var i:Int){
        //print(pistas[i+1])
        stop()
        song.text = "Canción: " + pistas[(0+(3*i))]
        artist.text = "Artista: " + pistas[1+(3*i)]
        
        let urls = "album" + pistas[2+(3*i)] + ".jpg"
        imagen.image = UIImage(named: urls)
        play()
        
    }
    
    private func stop(){
        if reproductor.isPlaying{
            reproductor.stop()
            reproductor.currentTime=0.0
        }
    }
    
    private func play(){
        if !reproductor.isPlaying{
            reproductor.volume = volum.value
            reproductor.play()
        }
    }
    
    @IBAction func Volumen() {
        
            reproductor.volume = volum.value
    }
    @IBAction func pista01() {
        let sonidoURL = Bundle.main.url(forResource: "pista" + pistas[2],withExtension:"aif")
        do{
            try reproductor=AVAudioPlayer(contentsOf: sonidoURL!)
        }catch{
            print("Error al cargar la cancion")
        }
        repro(Var: 0)
        
    }
    
    @IBAction func pista02() {
        let sonidoURL = Bundle.main.url(forResource: "pista" + pistas[5],withExtension:"aif")
        do{
            try reproductor=AVAudioPlayer(contentsOf: sonidoURL!)
        }catch{
            print("Error al cargar la cancion")
        }
        repro(Var: 1)
    }
    @IBAction func pista03() {
        let sonidoURL = Bundle.main.url(forResource: "pista" + pistas[8],withExtension:"aif")
        do{
            try reproductor=AVAudioPlayer(contentsOf: sonidoURL!)
        }catch{
            print("Error al cargar la cancion")
        }
        repro(Var: 2)
    }
    @IBAction func pista04() {
        let sonidoURL = Bundle.main.url(forResource: "pista" + pistas[11],withExtension:"aif")
        do{
            try reproductor=AVAudioPlayer(contentsOf: sonidoURL!)
        }catch{
            print("Error al cargar la cancion")
        }
        repro(Var: 3)
    }
    @IBAction func pista05() {
        let sonidoURL = Bundle.main.url(forResource: "pista" + pistas[14],withExtension:"aif")
        do{
            try reproductor=AVAudioPlayer(contentsOf: sonidoURL!)
        }catch{
            print("Error al cargar la cancion")
        }
        repro(Var: 4)
    }
    @IBAction func playing() {
        play()
    }
    
    @IBAction func pause() {
        if reproductor.isPlaying{
            reproductor.pause()
        }
    }
    @IBAction func detener() {
        if reproductor.isPlaying{
            reproductor.stop()
            reproductor.currentTime=0.0
        }
    }
    
    @IBAction func aleatorio() {
        let ale = Int(arc4random_uniform(5))
        let sonidoURL = Bundle.main.url(forResource: "pista" + pistas[2+(ale*3)],withExtension:"aif")
        do{
            try reproductor=AVAudioPlayer(contentsOf: sonidoURL!)
        }catch{
            print("Error al cargar la cancion")
        }
        repro(Var: ale)
    }
    
    
}

